Cubidion V11 — Dynamic Battles & Wardrobe

Upload index.html to your existing Cubidion-game GitHub Pages repository.
Your old save remains in the same browser.
Music is original synthesized audio using Web Audio, starting after interacting with the game.
Pet buffs apply in combat. Cosmetic gear can be purchased with in-game coins.
Preferences are stored locally. World-wide rankings still need the separate backend from prior versions.
